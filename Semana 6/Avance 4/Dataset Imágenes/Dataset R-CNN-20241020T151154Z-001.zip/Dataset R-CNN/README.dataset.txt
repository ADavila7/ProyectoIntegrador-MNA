# Thermal Region and Components > 2024-09-30 2:08am
https://universe.roboflow.com/adrians-workspace-sghcv/thermal-region-and-components

Provided by a Roboflow user
License: CC BY 4.0

